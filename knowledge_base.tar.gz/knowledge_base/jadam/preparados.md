# Preparados JADAM

## SMJ - Solución Microorganismos JADAM
**Ingredientes:**
- Mantillo de bosque (1 puñado)
- Patata cocida o papa (500g) - aporta alimento
- Agua de mar o sal marina (1L agua + 30g sal)
- Agua (hasta 20L)

**Proceso:**
1. Mezclar todos ingredientes
2. Dejar fermentar 3-7 días (18-25°C)
3. Usar cuando burbujea

**Aplicación:**
- Suelo: 1:20 a 1:100 con agua
- Foliar: 1:500 con agua
- Compost: 1:10 para activar

## FPJ - Jugo Fermentado Plantas
**Para crecimiento vegetativo:**
- Plantas jóvenes vigorosas (ortie, consoude)
- Peso igual de azúcar morena
- Fermentar 7-14 días
- Diluir 1:500 a 1:1000

## FAA - Aminoácidos Pescado
**Ingredientes:**
- Restos pescado fresco
- Azúcar morena (peso igual)
**Proceso:**
- Capas alternas pescado/azúcar
- 2-6 meses fermentación
- Diluir 1:1000
- Usar en vegetativo (NO en floración)
