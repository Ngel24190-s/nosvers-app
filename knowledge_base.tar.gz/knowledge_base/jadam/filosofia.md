# Filosofía JADAM

## Principios fundamentales
1. **Autosuficiencia total**: hacer TODO en la finca, coste ultra-bajo
2. **Microorganismos autóctonos**: no comprar, cultivar del propio suelo
3. **Ciclo cerrado**: cero residuos, todo se transforma
4. **Monocultivo sostenible**: con suelo vivo es posible (contra rotación tradicional)

## Diferencias con agricultura convencional ecológica
- NO usar inputs comerciales (incluso ecológicos)
- NO patentes, todo libre acceso
- Foco en microbiología del suelo, no solo nutrientes

## Referencias
- Youngsang Cho (hijo de Dr. Cho Han Kyu - KNF)
- Libros JADAM traducidos al español
