# Asociaciones de Cultivos - La Tanina

## Principios científicos
- NO reducir marcos de plantación por asociar
- Marco viene dado por: calidad suelo, humedad, microorganismos
- Excepción: tagetes + tomates (tagetes sembrado después)

## Tipos de asociaciones
1. **Alelopatía positiva**: sustancias beneficiosas entre plantas
2. **Uso estratificado**: raíces a diferentes profundidades
3. **Atracción benéficos**: flores para polinizadores y depredadores
4. **Fijación nitrógeno**: leguminosas con otras plantas

## Control biológico
- Escarabajos contra babosas (acolchado corteza)
- Nematodos Phasmarhabditis hermaphrodita (solo Europa)
- Fomentar depredadores naturales

## Microbiología práctica
- Hongos micorrícicos
- Bacterias fijadoras N
- Atención a pH, humedad, estructura
