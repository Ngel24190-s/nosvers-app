# Calendario Biodinámico María Thun

## Días según influencia lunar
- **Día raíz**: Luna en signos tierra (Tauro, Virgo, Capricornio) → zanahorias, rábanos, patatas
- **Día flor**: Luna en signos aire (Géminis, Libra, Acuario) → flores, brócoli, coliflor
- **Día fruto**: Luna en signos fuego (Aries, Leo, Sagitario) → tomates, calabazas, cereales
- **Día hoja**: Luna en signos agua (Cáncer, Escorpio, Piscis) → lechugas, espinacas, acelgas

## Aplicaciones prácticas
- **Siembra**: según parte que se cosecha
- **Trasplante**: evitar nodos lunares
- **Cosecha**: en día correspondiente para mejor conservación
- **Preparados BD**: aplicar en días específicos

## Fuentes
- María Thun calendario anual
- Asociación Biodinámica
