# Preparados Biodinámicos

## BD 500 - Cuerno estiércol
**Preparación:**
- Estiércol vaca en cuerno de vaca
- Enterrar 6 meses (otoño-primavera)
**Aplicación:**
- Diluir 60g en 30L agua
- Dinamizar 1 hora (vórtice + caos)
- Aplicar al atardecer sobre suelo
**Efecto:** Vitaliza suelo, estimula raíces y vida microbiana

## BD 501 - Cuerno sílice
**Preparación:**
- Cuarzo molido en cuerno
- Enterrar 6 meses (primavera-otoño)
**Aplicación:**
- Diluir 4g en 30L agua
- Dinamizar 1 hora
- Aplicar temprano mañana sobre plantas
**Efecto:** Fortalece plantas, mejora fotosíntesis y resistencia

## Compost biodinámico
Uso de preparados 502-507 (milenrama, manzanilla, ortiga, etc)
