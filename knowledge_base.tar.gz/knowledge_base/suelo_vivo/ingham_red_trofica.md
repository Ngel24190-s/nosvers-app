# Red Trófica del Suelo - Elaine Ingham

## Componentes de la red alimentaria
1. **Bacterias**: descomponen MO simple, fijan nitrógeno
2. **Hongos**: descomponen lignina, celulosa; forman micorrizas
3. **Protozoos**: comen bacterias, liberan N disponible para plantas
4. **Nematodos**: algunos beneficiosos (comen bacterias/hongos), otros patógenos
5. **Artrópodos**: fragmentan MO, airean suelo
6. **Lombrices**: ingenieros del suelo

## Ratio Bacterias:Hongos
- Hortalizas: 1:1
- Praderas: 1:2 a 1:5
- Bosques maduros: 1:100+

## Principios clave Ingham
- **Nunca perturbar** la red (no laboreo, no químicos)
- **Alimentar la red**, no las plantas directamente
- **Inocular** con compost de calidad
- **Proteger** con mulch permanente

## Thé de compost aireado
- Compost maduro + agua + melaza + aireación 24-48h
- Multiplica microorganismos x1000
