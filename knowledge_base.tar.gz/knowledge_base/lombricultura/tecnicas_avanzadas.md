# Técnicas Avanzadas

## División de camas (escalado)
- Señal: densidad >3kg/m², consumo rápido, cocones visibles
- Método: dividir 50/50 con litière nueva
- Timing: primavera/otoño preferible

## Cosecha profesional
- Método luz: lombrices huyen de luz, recoger capas
- Trommel rotativo: malla 6-8mm
- Importante: mantener humedad durante proceso

## Thé de lombric (lixiviado)
- Diluir 1:10 con agua no clorada
- Aplicar inmediatamente (microorganismos activos)
- NO exponer al sol directo

## IBCs sistema
- Ventajas: modular, recuperación lixiviados, stackable
- Corte: superior como tapa, inferior como base
- Drenaje: grifo en punto bajo
- Aireación opcional: pump acuario en tanque lixiviados
