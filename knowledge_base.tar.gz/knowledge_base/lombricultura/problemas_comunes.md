# Problemas Comunes en Lombricultura

## Lombrices suben a la tapa / intentan escapar
**Causas:**
- pH ácido (<6.0) → añadir cáscara huevo triturada
- Exceso humedad (>90%) → añadir cartón seco
- Falta aireación → voltear suavemente
- Temperatura inadecuada
- Presencia de amoníaco (exceso nitrógeno) → añadir carbono

## Cocones no eclosionan
- Temperatura <15°C → esperar calor o proteger
- Exceso sequedad → aumentar humedad gradualmente

## Malos olores
- Anaerobiosis → voltear y añadir material estructurante
- Exceso proteína → equilibrar con carbono

## Plagas
- Moscas → cubrir bien con cartón
- Ácaros blancos → normal si no excesivos
