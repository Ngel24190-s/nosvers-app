# Lombricultura - Fundamentos

## Especies principales
- **Eisenia fetida** (lombriz roja californiana): Ideal para compost, 15-25°C óptimo
- **Eisenia andrei**: Similar a fetida, más tolerante al calor

## Parámetros críticos
- **Temperatura**: 15-25°C óptimo, <10°C hibernación, >30°C estrés/muerte
- **Humedad**: 70-85% (test puño: 1-2 gotas)
- **pH**: 6.5-7.5
- **Aireación**: Crucial, evitar compactación

## Alimentación
- Ratio C/N: 25-30:1
- Capas finas <5cm
- Cubrir con cartón húmedo
- EVITAR: cítricos, cebolla, ajo, proteína animal, lácteos

## Fuentes
- Manual JADAM
- Estudios universitarios lombricultura
- Canal El Lombricero
